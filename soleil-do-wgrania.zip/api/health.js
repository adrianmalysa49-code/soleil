import crypto from 'crypto';

// ─────────────────────────────────────────────────────────────
// WERYFIKACJA SESJI CLERK (bez dodatkowych zależności)
// Dane zdrowotne nie mogą opierać się na userId przysłanym z przeglądarki,
// bo userId jest jawny (np. w linkach polecających). Sprawdzamy podpis tokenu
// sesji Clerk kluczem publicznym (JWKS) i bierzemy userId z tokenu.
// ─────────────────────────────────────────────────────────────
const DEFAULT_PUBLISHABLE_KEY = 'pk_test_YXdhaXRlZC1taW5rLTQ1LmNsZXJrLmFjY291bnRzLmRldiQ';

function clerkIssuer() {
  const pk = process.env.CLERK_PUBLISHABLE_KEY || DEFAULT_PUBLISHABLE_KEY;
  const encoded = pk.split('_').slice(2).join('_');
  const domain = Buffer.from(encoded, 'base64').toString('utf8').replace(/\$$/, '');
  return `https://${domain}`;
}

let jwksCache = { keys: null, fetchedAt: 0 };

async function getJwks(issuer) {
  if (jwksCache.keys && Date.now() - jwksCache.fetchedAt < 60 * 60 * 1000) return jwksCache.keys;
  const res = await fetch(`${issuer}/.well-known/jwks.json`);
  if (!res.ok) throw new Error('JWKS niedostępne');
  const data = await res.json();
  jwksCache = { keys: data.keys || [], fetchedAt: Date.now() };
  return jwksCache.keys;
}

function b64urlToBuffer(str) {
  return Buffer.from(str.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

export async function verifyClerkToken(authHeader) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7);
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  let header, payload;
  try {
    header = JSON.parse(b64urlToBuffer(parts[0]).toString('utf8'));
    payload = JSON.parse(b64urlToBuffer(parts[1]).toString('utf8'));
  } catch { return null; }

  if (header.alg !== 'RS256') return null;

  const issuer = clerkIssuer();
  if (payload.iss !== issuer) return null;

  const now = Math.floor(Date.now() / 1000);
  if (typeof payload.exp !== 'number' || payload.exp < now - 5) return null;
  if (typeof payload.nbf === 'number' && payload.nbf > now + 5) return null;

  const keys = await getJwks(issuer);
  const jwk = keys.find(k => k.kid === header.kid);
  if (!jwk) return null;

  const publicKey = crypto.createPublicKey({ key: jwk, format: 'jwk' });
  const valid = crypto.verify(
    'RSA-SHA256',
    Buffer.from(`${parts[0]}.${parts[1]}`),
    publicKey,
    b64urlToBuffer(parts[2])
  );
  if (!valid || !payload.sub) return null;
  return payload.sub;
}

// ─────────────────────────────────────────────────────────────
// SŁOWNIKI (muszą odpowiadać kluczom używanym w index.html)
// ─────────────────────────────────────────────────────────────
const ZONES = ['head_neck', 'shoulders', 'chest', 'arms', 'core', 'legs'];
const CHARACTERS = ['sharp', 'dull', 'burning', 'throbbing', 'pressure', 'stiff', 'other'];
const ONSETS = ['lt1h', 'hours', 'days', 'week'];
const PROGRESSIONS = ['better', 'same', 'worse'];
const ASSOCIATED = ['fever', 'nausea', 'dizziness', 'breathless', 'numbness', 'swelling', 'stroke', 'fainting'];
const RED_FLAGS = {
  head_neck: ['thunderclap', 'head_injury', 'stiff_neck_fever', 'confusion'],
  shoulders: ['shoulder_chest', 'trauma_deform'],
  chest: ['radiating', 'pressure_strong', 'cold_sweat'],
  arms: ['sudden_weakness', 'trauma_deform', 'arm_chest'],
  core: ['rigid', 'blood', 'severe_cant_move'],
  legs: ['dvt', 'cant_bear', 'cold_pale']
};

// ─────────────────────────────────────────────────────────────
// TRIAGE — twarde reguły, celowo NIE zależą od modelu AI.
// Zwraca poziom pilności, nigdy diagnozę.
// ─────────────────────────────────────────────────────────────
export function computeTriage({ zone, intensity, onset, progression, associated, redFlags }) {
  const has = (k) => associated.includes(k);

  if (redFlags.length > 0) return 'emergency';
  if (has('stroke') || has('fainting')) return 'emergency';
  if (zone === 'chest' && (has('breathless') || intensity >= 7)) return 'emergency';
  if (intensity >= 9 && progression === 'worse') return 'emergency';

  if (intensity >= 7) return 'see_doctor';
  if (progression === 'worse') return 'see_doctor';
  if (has('fever') || has('breathless') || has('numbness')) return 'see_doctor';
  if (onset === 'week') return 'see_doctor';
  if (has('nausea') && intensity >= 5) return 'see_doctor';

  return 'monitor';
}

function cleanList(value, allowed) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter(v => allowed.includes(v)))];
}

export default async function handler(req, res) {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
  if (!supabaseUrl || !supabaseKey) return res.status(500).json({ error: 'Brak konfiguracji Supabase' });

  let userId;
  try { userId = await verifyClerkToken(req.headers.authorization); }
  catch (err) { console.error('Auth error:', err); userId = null; }
  if (!userId) return res.status(401).json({ error: 'Brak autoryzacji' });

  const sbHeaders = { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}`, 'Content-Type': 'application/json' };
  const uid = encodeURIComponent(userId);

  // GET — historia epizodów z ostatnich 90 dni
  if (req.method === 'GET') {
    try {
      const since = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
      const r = await fetch(
        `${supabaseUrl}/rest/v1/health_episodes?user_id=eq.${uid}&created_at=gte.${since}&order=created_at.desc&limit=200`,
        { headers: sbHeaders }
      );
      const episodes = await r.json();
      return res.status(200).json({ episodes: Array.isArray(episodes) ? episodes : [] });
    } catch (err) {
      console.error('Health GET error:', err);
      return res.status(500).json({ error: 'Błąd serwera' });
    }
  }

  if (req.method === 'POST') {
    const { action } = req.body || {};

    // Nowy epizod — walidacja, triage, zapis
    if (action === 'create') {
      const b = req.body;
      if (!ZONES.includes(b.zone)) return res.status(400).json({ error: 'Nieprawidłowa strefa' });
      const intensity = Number.isInteger(b.intensity) ? Math.min(10, Math.max(0, b.intensity)) : null;
      if (intensity === null) return res.status(400).json({ error: 'Brak natężenia' });

      const episode = {
        user_id: userId,
        zone: b.zone,
        sub_location: typeof b.subLocation === 'string' ? b.subLocation.slice(0, 40) : null,
        character: CHARACTERS.includes(b.character) ? b.character : 'other',
        onset: ONSETS.includes(b.onset) ? b.onset : 'hours',
        intensity,
        progression: PROGRESSIONS.includes(b.progression) ? b.progression : 'same',
        associated: cleanList(b.associated, ASSOCIATED),
        red_flags: cleanList(b.redFlags, RED_FLAGS[b.zone])
      };
      episode.triage = computeTriage({
        zone: episode.zone, intensity: episode.intensity, onset: episode.onset,
        progression: episode.progression, associated: episode.associated, redFlags: episode.red_flags
      });
      episode.status = 'open';

      try {
        const r = await fetch(`${supabaseUrl}/rest/v1/health_episodes`, {
          method: 'POST',
          headers: { ...sbHeaders, 'Prefer': 'return=representation' },
          body: JSON.stringify(episode)
        });
        const saved = await r.json();
        if (!r.ok) { console.error('Health insert error:', saved); return res.status(500).json({ error: 'Błąd zapisu' }); }
        return res.status(200).json({ episode: Array.isArray(saved) ? saved[0] : saved });
      } catch (err) {
        console.error('Health POST error:', err);
        return res.status(500).json({ error: 'Błąd serwera' });
      }
    }

    // Follow-up — „Jak się teraz czujesz?”
    if (action === 'followup') {
      const { episodeId, answer } = req.body;
      if (!episodeId || !['better', 'same', 'worse'].includes(answer)) return res.status(400).json({ error: 'Nieprawidłowe dane' });
      const status = answer === 'better' ? 'resolved' : answer === 'worse' ? 'escalated' : 'open';
      try {
        await fetch(
          `${supabaseUrl}/rest/v1/health_episodes?id=eq.${encodeURIComponent(episodeId)}&user_id=eq.${uid}`,
          { method: 'PATCH', headers: sbHeaders, body: JSON.stringify({ status, followup_answer: answer, last_followup_at: new Date().toISOString() }) }
        );
        return res.status(200).json({ success: true, status });
      } catch (err) {
        console.error('Health followup error:', err);
        return res.status(500).json({ error: 'Błąd serwera' });
      }
    }

    return res.status(400).json({ error: 'Nieznana akcja' });
  }

  return res.status(405).json({ error: 'Metoda niedozwolona' });
}
