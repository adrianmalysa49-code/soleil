const REWARD_DAYS = 7;

export default async function handler(req, res) {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;

  if (!supabaseUrl || !supabaseKey) {
    return res.status(500).json({ error: 'Brak konfiguracji Supabase' });
  }

  // POST — zarejestruj polecenie (wywoływane raz, po zalogowaniu z linku ?ref=)
  if (req.method === 'POST') {
    const { referrerId, referredId } = req.body;
    if (!referrerId || !referredId) return res.status(400).json({ error: 'Brak danych' });
    if (referrerId === referredId) return res.status(400).json({ error: 'Nie można polecić samego siebie' });

    try {
      // Sprawdź, czy ten użytkownik nie ma już zarejestrowanego polecenia (unikalność po referred_id)
      const existingRes = await fetch(
        `${supabaseUrl}/rest/v1/referrals?referred_id=eq.${referredId}`,
        { headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}` } }
      );
      const existing = await existingRes.json();
      if (existing && existing.length > 0) {
        return res.status(200).json({ success: true, alreadyRegistered: true });
      }

      const insertRes = await fetch(`${supabaseUrl}/rest/v1/referrals`, {
        method: 'POST',
        headers: {
          'apikey': supabaseKey,
          'Authorization': `Bearer ${supabaseKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify({ referrer_id: referrerId, referred_id: referredId, status: 'pending' })
      });

      if (!insertRes.ok) return res.status(500).json({ error: 'Błąd zapisu polecenia' });
      return res.status(200).json({ success: true });
    } catch (err) {
      console.error('Referral registration error:', err);
      return res.status(500).json({ error: 'Błąd serwera' });
    }
  }

  // GET — statystyki poleceń danego użytkownika
  if (req.method === 'GET') {
    const { userId } = req.query;
    if (!userId) return res.status(400).json({ error: 'Brak userId' });

    try {
      const response = await fetch(
        `${supabaseUrl}/rest/v1/referrals?referrer_id=eq.${userId}&select=status`,
        { headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}` } }
      );
      const data = await response.json();
      const list = Array.isArray(data) ? data : [];
      const rewardedCount = list.filter(r => r.status === 'rewarded').length;
      const pendingCount = list.filter(r => r.status === 'pending').length;

      return res.status(200).json({ rewardedCount, pendingCount, rewardDays: REWARD_DAYS });
    } catch (err) {
      console.error('Referral stats error:', err);
      return res.status(500).json({ error: 'Błąd serwera' });
    }
  }

  return res.status(405).json({ error: 'Metoda niedozwolona' });
}

// Nagradza oczekujące polecenie po tym, jak polecony użytkownik zapisze swój pierwszy nastrój.
// Wywoływane z api/mood.js. Zwraca true, jeśli nagroda została przyznana.
export async function rewardReferralIfPending(supabaseUrl, supabaseKey, referredId) {
  try {
    const pendingRes = await fetch(
      `${supabaseUrl}/rest/v1/referrals?referred_id=eq.${referredId}&status=eq.pending`,
      { headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}` } }
    );
    const pending = await pendingRes.json();
    if (!pending || pending.length === 0) return false;

    const referral = pending[0];
    const referrerId = referral.referrer_id;

    await Promise.all([
      grantPremiumDays(supabaseUrl, supabaseKey, referrerId, REWARD_DAYS),
      grantPremiumDays(supabaseUrl, supabaseKey, referredId, REWARD_DAYS)
    ]);

    await fetch(`${supabaseUrl}/rest/v1/referrals?id=eq.${referral.id}`, {
      method: 'PATCH',
      headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'rewarded', rewarded_at: new Date().toISOString() })
    });

    return true;
  } catch (err) {
    console.error('Reward referral error:', err);
    return false;
  }
}

// Wydłuża premium_until użytkownika o `days` dni, licząc od dziś lub od obecnej daty wygaśnięcia (jeśli jest w przyszłości)
async function grantPremiumDays(supabaseUrl, supabaseKey, userId, days) {
  const existingRes = await fetch(
    `${supabaseUrl}/rest/v1/user_subscriptions?user_id=eq.${userId}`,
    { headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}` } }
  );
  const existing = await existingRes.json();
  const now = new Date();
  const current = existing && existing.length > 0 ? existing[0] : null;
  const currentUntil = current && current.premium_until ? new Date(current.premium_until) : null;
  const base = currentUntil && currentUntil > now ? currentUntil : now;
  const newUntil = new Date(base.getTime() + days * 24 * 60 * 60 * 1000).toISOString();

  if (current) {
    await fetch(`${supabaseUrl}/rest/v1/user_subscriptions?user_id=eq.${userId}`, {
      method: 'PATCH',
      headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ premium_until: newUntil, updated_at: new Date().toISOString() })
    });
  } else {
    await fetch(`${supabaseUrl}/rest/v1/user_subscriptions`, {
      method: 'POST',
      headers: { 'apikey': supabaseKey, 'Authorization': `Bearer ${supabaseKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, is_premium: false, subscription_status: 'inactive', premium_until: newUntil })
    });
  }
}
